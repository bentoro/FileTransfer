import java.io.*;
import java.net.*;

public class svr {
  private static ServerSocket ListeningSocket;
	private static Socket ClientSocket;
	private static Socket clt;

	public static void main(String args[]) throws IOException, ClassNotFoundException {
		cmdSocketStart();
		dataSocketStart();

		// clients input stream
		InputStream ofs = ClientSocket.getInputStream();
		DataInputStream in = new DataInputStream(ofs);
		// store message from client
		String msg = in.readUTF();
		System.out.println("message from client:" + msg);

		OutputStream outsvr = clt.getOutputStream();
		DataOutputStream out = new DataOutputStream(outsvr);
		DataInputStream ins = new DataInputStream(clt.getInputStream());

		if (msg.matches("GET")) {

			String file = "totoro.jpg";
			File myFile = new File("totoro.jpg");
			int siz = (int) myFile.length();
			System.out.println("File name:" + file);

			FileInputStream fis = new FileInputStream(file);
			byte[] buffer = new byte[siz];

			out.writeUTF(Integer.toString(siz));
			// While stream has data write to buffer
      fis.read(buffer);
      out.write(buffer);
			
		} else if (msg.matches("SEND")) {

			try {

				FileOutputStream file1 = new FileOutputStream("totoro1.jpg");
				msg = in.readUTF();

				byte[] buff = new byte[Integer.parseInt(msg)];
				int filesize = Integer.parseInt(msg);
				System.out.println("MESSAGE FROM CLIENT FILE SIZE= " + Integer.parseInt(msg));

        ins.read(buff);
        file1.write(buff);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public static void cmdSocketStart(/* String host, int port */) throws UnknownHostException, IOException {
		System.out.println("Connecting to port 7005");
		ListeningSocket = new ServerSocket(4444);
		// ServerSocket svr = new ServerSocket(7005);
		System.out.println("======================================");
		System.out.println("Waiting for client to connect!");
		ClientSocket = ListeningSocket.accept();
		System.out.println("======================================");
		System.out.println("Client has connected to the server");
		System.out.println("======================================");
	}

	public static void dataSocketStart(/* int port */) throws IOException {
		clt = new Socket("127.0.0.1", 7005);
		System.out.println("Connected to 127.0.0.1 and port 4444!");
		System.out.println("======================================");
	}

	public static void disconnect() throws IOException {
		System.out.println("Closing connection");
		// in.close();
		// out.close();
		ListeningSocket.close();
		ClientSocket.close();
	}
}
